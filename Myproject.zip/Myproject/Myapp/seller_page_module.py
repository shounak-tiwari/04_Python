from django.shortcuts import render,redirect,get_object_or_404


def sellerpage(request):
    return render(request,'sellerpage.html')



def seller_login(request):
    return render(request,'loginpage.html')