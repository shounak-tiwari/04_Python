from django.shortcuts import render,redirect,get_object_or_404
from django.http import HttpResponse

# import model
from .models import  Item
# import forms 
from .forms import ItemForms


def buynow(request,id):
    pass


def cart_page(request,id):
    pass