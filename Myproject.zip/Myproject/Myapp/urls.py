from django.urls import path
from .views import item_list, item_update, Item_create,item_delete,homepage
from .payment_buy_cart import buynow,cart_page
from .seller_page_module import sellerpage,seller_login


urlpatterns = [
    path('',homepage,name='homepage'),
    path('item_list/',item_list,name='item_list'),
    path('add/',Item_create,name="Item_create"),
    path('edit/<int:id>/',item_update,name='item_update'),
    path('delete/<int:id>',item_delete,name="item_delete"),
    path('buynow/<int:id>/',buynow,name='buynow'),
    path('cart_page/<int:id>/',cart_page,name='cart_page'),
    path('sellerpage/',sellerpage,name='sellerpage'),
    path('seller_login/',seller_login,name="seller_login")
]
