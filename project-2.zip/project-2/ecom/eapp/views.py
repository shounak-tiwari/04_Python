from django.shortcuts import render,redirect,get_object_or_404
from .forms import AddproductForms
from django.http import HttpResponse

from .models import Addproduct


def index(request):
    if request.method == "POST":
        form = AddproductForms(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect("homepage")       
    else:
        form = AddproductForms()

    return render(request, 'index.html', {'form': form})


def HomePage(request):
    temp= Addproduct.objects.all()

    return render(request,'Home.html',{'data':temp})

def adminpage(request):
    temp = Addproduct.objects.all()
    return render(request,'adminfile.html',{'data':temp})

def delete(request,id):
    item = get_object_or_404(Addproduct,id=id)

    if request.method =="POST":
        item.delete()
        return redirect('adminpage')
    return render(request,'delete.html',{'item' : item})

def update(request,id):
    item = get_object_or_404(Addproduct,id=id)
    if request.method == "POST":
        form = AddproductForms(request.POST,request.FILES,instance=item)
        if form.is_valid():
            form.save()
            return redirect('adminpage')
    else:
        form = AddproductForms(instance=item)
    return render(request,'index.html',{'form':form})