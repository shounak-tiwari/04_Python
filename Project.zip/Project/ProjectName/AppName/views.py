from django.http import HttpResponse

def Welcome(request):
    return HttpResponse("welcome in world of django !! ")
