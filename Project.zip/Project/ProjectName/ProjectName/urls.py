
from django.contrib import admin
from django.urls import path
from AppName.views import Welcome

urlpatterns = [
    path('',Welcome,name="welcome"),
    path('admin/', admin.site.urls),
]
